# About This Site

This website is built with the **Astro** framework using the [Twilight](https://github.com/Spr-Aachen/Twilight) template.

::github{repo="Spr-Aachen/Twilight"}